você nasce de minhas mãos
entre meus filhos e pelos mesmos
seus olhos enxergam
enxergam
mais do que os demais por hora
uma Folha se cai
meu coração dói
sua Catarata é cultivada
você reclama, não vê o que te dei
apenas um a mais
pra mim, um estante
feche seus olhos, conte 1
é o que você sente
agora, seus olhos estão abertos
você é cego
se nega a me ver
auto ignorância do berço que nasceu
da Mata que vive
do ar que Respira
me nega. como algo longe de mim mesma
se ilude à minha auxência
se afasta de mim
mas é em vão
eu sou seu sangue
seu cálcio, seu ácido
sou seu início e seu limíte
sua luta é inevitável, todas são
mas apenas a sua é arrogante
e quando menos imagina
o ultimo krebs que tera
e como em um instante
estará preso no que queima
rodiado pelo que odeia
enterrado pelo o que despreza
e retornará à mim.